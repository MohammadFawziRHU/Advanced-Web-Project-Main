<?php
// Retrieve form data
if(!empty($_POST['username']) && !empty($_POST['password'])) {
$username = $_POST['username'];
$password = $_POST['password'];

// Your authentication logic here (for demonstration purposes, using hardcoded values)
$valid_username = "admin@tr";
$valid_password = "password";

// Verify username and password
if ($username === $valid_username && $password === $valid_password) {
    // Authentication successful
    session_start();
    $_SESSION['username'] = $username;
    header("Location: index.php");
    exit;
} else {
    // Authentication failed
    echo 'Username or password failed';
}
} else{
    echo "Form data not received";
}
?>