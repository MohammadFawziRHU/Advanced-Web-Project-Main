//navbar
function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
      x.className += " responsive";
    } else {
      x.className = "topnav";
    }
  }
  
  //sign up form 
  
  // Get the modal
  var modal = document.getElementById('id01');
  
  // When the user clicks anywhere outside of the modal, close it
  window.onclick = function(event) {
    if (event.target == modal) {
      modal.style.display = "none";
    }
  }
  

  
  //team number
  $(document).ready(function () {
    $('.slider-container').on('scroll', function () {
        const scrollLeft = $(this).scrollLeft();
        const slideWidth = $('.slide').outerWidth();
        const currentIndex = Math.round(scrollLeft / slideWidth);
  
        updateFeedback(currentIndex + 1);
    });
  
    function updateFeedback(index) {
        $('.customernumber span').text(index);
    }
  });
  
  
  
  
  var mySwiper = new Swiper('.swiper-container', {
    // Optional parameters
    slidesPerView: 1,
    spaceBetween: 10,
    loop: true,
  
    // If you need pagination
    pagination: {
      el: '.swiper-pagination',
      clickable: true,
    },
  
    // Navigation arrows
    navigation: {
      nextEl: '.swiper-button-next',
      prevEl: '.swiper-button-prev',
    },
  });
  
  
  
  