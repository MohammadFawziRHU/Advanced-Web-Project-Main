<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Books Library</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <style>
        form{
            margin:20px;
            border-radius:2px;
        }
    </style>
</head>
<body>




<h1><center>Admin Page</center></h1>
<form action="" method="post">
  <div class="row mb-3">
    <label for="inputTitle" class="col-sm-2 col-form-label">Title</label>
    <div class="col-sm-10">
      <input type="email" class="form-control" id="inputTitle">
    </div>
  </div>
  <div class="input-group mb-3">
  <label class="col-sm-2 col-form-label" for="inputAuthor">Author</label>
  <select class="form-select" id="inputAuthor">
    <option selected value="0">Select Author</option>
  </select>
</div>
  
  <fieldset class="row mb-3">
    <legend class="col-form-label col-sm-2 pt-0">Genre:</legend>
    <div class="col-sm-10">
      <div class="form-check">
        <input class="form-check-input" type="radio" name="gridRadios" id="gridRadios1" value="Fiction">
        <label class="form-check-label" for="gridRadios1">
          Fiction
        </label>
      </div>
      <div class="form-check">
        <input class="form-check-input" type="radio" name="gridRadios" id="gridRadios2" value="Dystopian">
        <label class="form-check-label" for="gridRadios2">
          Dystopian
        </label>
      </div>
      <div class="form-check">
        <input class="form-check-input" type="radio" name="gridRadios" id="gridRadios3" value="Romance">
        <label class="form-check-label" for="gridRadios3">
          Romance
        </label>
      </div>
    </div>

   
  </fieldset>

  <div class="input-group mb-3">
  <label class="input-group-text" for="inputPub">Publication Year</label>
  <select class="form-select" id="inputPub">
    <option selected value="0">Select a section to edit</option>
    <option value="asc">Ascending</option>
    <option value="desc">Descending</option>
  </select>
</div>

  
  <button type="submit" class="btn btn-primary">Reset</button>
</form>

<div class="container-fluid" id = "card-container" >
 
</div>


 






<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="main.js"></script>
</body>
</html>